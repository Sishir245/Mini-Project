from django.apps import AppConfig


class VoltaireConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'voltaire'
