
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_USE_TLS = True
EMAIL_PORT = 587
EMAIL_HOST_USER = 'sishirrijal35@gmail.com'
EMAIL_HOST_PASSWORD = 'uiqnwvbxvyxtxdbf'
